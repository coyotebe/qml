# qt-qml-opengles-triangle
OpenGL ES 2.0 Triangle rendered in QML element GLESTriangleView
